/**
 * 
 */
/**
 * 
 */
module tank {
	requires java.desktop;
}